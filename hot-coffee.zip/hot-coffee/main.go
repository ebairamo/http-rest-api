package main

import "hot-coffee/cmd"

func main() {
	cmd.Run()
}
